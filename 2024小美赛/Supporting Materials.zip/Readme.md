Here are some notes regarding the "Supporting Materials" file:

In the appendix of the paper, we only included some key sections of the core logic code. However, the full version is available in this folder. The core code can be executed via the `main.py` file to generate the shape data we solved, while the `main2.py` file is used for visualizing the resulting data.

Due to the computational intensity, running `main.py` may take a very long time. To verify our results, we have packaged the generated shape data in the `plotlist.txt` file. You can directly run the `main2.py` file to view the results.