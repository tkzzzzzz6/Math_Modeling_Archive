# heesch_machine
- can only make the first corona around a tile atm
1) Create a shape inside of main.py and run it to write a file with some data to do make plots with
2) Then run main2.py to make the plot

I split it up this way since I am using pypy3 to speed up the compile of main.py, but cant figure out how to use matplotlib with pypy3
